"use client"

import { useState } from "react"
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"
import { Button } from "@/components/ui/button"
import { Input } from "@/components/ui/input"
import { Badge } from "@/components/ui/badge"
import { Mic, Search, MapPin, Clock, Wallet, Award, Briefcase } from "lucide-react"
import { useToast } from "@/components/ui/use-toast"

export default function JobSearchPage() {
  const [isListening, setIsListening] = useState(false)
  const [searchQuery, setSearchQuery] = useState("")
  const [searchResults, setSearchResults] = useState<typeof mockJobs | null>(null)
  const { toast } = useToast()

  // Mock function to simulate voice recognition
  const handleVoiceSearch = () => {
    setIsListening(true)

    // Simulate voice processing delay
    setTimeout(() => {
      // Simulate receiving voice input
      const voiceQueries = ["Construction work in Delhi", "Delivery jobs in Gurgaon", "Part-time work in Noida"]
      const randomQuery = voiceQueries[Math.floor(Math.random() * voiceQueries.length)]
      setSearchQuery(randomQuery)
      setIsListening(false)

      // Simulate search
      handleSearch(randomQuery)

      toast({
        title: "Voice input processed",
        description: `Searching for: "${randomQuery}"`,
      })
    }, 2000)
  }

  // Mock function to simulate search
  const handleSearch = (query = searchQuery) => {
    // Simulate API call delay
    setTimeout(() => {
      // Filter mock jobs based on query
      const filteredJobs = mockJobs.filter((job) => {
        const searchTerms = query.toLowerCase()
        return (
          job.title.toLowerCase().includes(searchTerms) ||
          job.location.toLowerCase().includes(searchTerms) ||
          job.type.toLowerCase().includes(searchTerms) ||
          job.company.toLowerCase().includes(searchTerms)
        )
      })

      setSearchResults(filteredJobs.length > 0 ? filteredJobs : mockJobs)
    }, 500)
  }

  return (
    <div className="flex flex-col p-6 space-y-6">
      <div className="flex flex-col space-y-2">
        <h1 className="text-3xl font-bold tracking-tight">Find Your Next Job</h1>
        <p className="text-muted-foreground">Use voice commands or text search to find jobs that match your skills</p>
      </div>

      <Card>
        <CardContent className="pt-6">
          <div className="flex flex-col md:flex-row gap-4">
            <div className="relative flex-1">
              <Search className="absolute left-3 top-3 h-4 w-4 text-muted-foreground" />
              <Input
                placeholder="Search jobs by title, location, or type..."
                className="pl-9"
                value={searchQuery}
                onChange={(e) => setSearchQuery(e.target.value)}
                onKeyDown={(e) => e.key === "Enter" && handleSearch()}
              />
            </div>
            <div className="flex gap-2">
              <Button variant="outline" className="relative" onClick={handleVoiceSearch} disabled={isListening}>
                {isListening && (
                  <span className="absolute inset-0 flex items-center justify-center">
                    <span className="absolute inline-flex h-full w-full animate-pulse rounded-full bg-primary/20"></span>
                    <span className="absolute inline-flex h-3/4 w-3/4 animate-pulse rounded-full bg-primary/40 delay-150"></span>
                  </span>
                )}
                <Mic className={`h-4 w-4 ${isListening ? "text-primary" : ""}`} />
                <span className="ml-2">Voice Search</span>
              </Button>
              <Button onClick={() => handleSearch()}>
                <Search className="h-4 w-4 mr-2" />
                Search
              </Button>
            </div>
          </div>

          <div className="mt-4 flex flex-wrap gap-2">
            <Badge variant="outline" className="cursor-pointer" onClick={() => setSearchQuery("Construction")}>
              Construction
            </Badge>
            <Badge variant="outline" className="cursor-pointer" onClick={() => setSearchQuery("Delivery")}>
              Delivery
            </Badge>
            <Badge variant="outline" className="cursor-pointer" onClick={() => setSearchQuery("Delhi")}>
              Delhi
            </Badge>
            <Badge variant="outline" className="cursor-pointer" onClick={() => setSearchQuery("Part-time")}>
              Part-time
            </Badge>
            <Badge variant="outline" className="cursor-pointer" onClick={() => setSearchQuery("Warehouse")}>
              Warehouse
            </Badge>
          </div>
        </CardContent>
      </Card>

      <div className="mt-6">
        <h2 className="text-xl font-semibold mb-4">
          {searchResults ? `Search Results (${searchResults.length})` : "Recommended Jobs"}
        </h2>

        <div className="grid gap-6 md:grid-cols-2 lg:grid-cols-3">
          {(searchResults || mockJobs).map((job) => (
            <Card key={job.id} className="overflow-hidden">
              <CardHeader className="pb-3">
                <div className="flex justify-between items-start">
                  <div>
                    <CardTitle className="text-lg">{job.title}</CardTitle>
                    <CardDescription className="mt-1">{job.company}</CardDescription>
                  </div>
                  {job.premium && <Badge>Premium</Badge>}
                </div>
              </CardHeader>
              <CardContent>
                <div className="space-y-3 text-sm">
                  <div className="flex items-center">
                    <MapPin className="h-4 w-4 mr-2 text-muted-foreground" />
                    <span>{job.location}</span>
                  </div>
                  <div className="flex items-center">
                    <Briefcase className="h-4 w-4 mr-2 text-muted-foreground" />
                    <span>{job.type}</span>
                  </div>
                  <div className="flex items-center">
                    <Clock className="h-4 w-4 mr-2 text-muted-foreground" />
                    <span>{job.duration}</span>
                  </div>
                  <div className="flex items-center">
                    <Wallet className="h-4 w-4 mr-2 text-muted-foreground" />
                    <span>₹{job.salary}</span>
                  </div>
                  <div className="flex items-center">
                    <Award className="h-4 w-4 mr-2 text-muted-foreground" />
                    <span>+{job.points} loyalty points</span>
                  </div>
                </div>
                <div className="mt-4 flex gap-2">
                  <Button className="flex-1">Apply Now</Button>
                  <Button variant="outline" className="flex-1">
                    Details
                  </Button>
                </div>
              </CardContent>
            </Card>
          ))}
        </div>
      </div>
    </div>
  )
}

const mockJobs = [
  {
    id: 1,
    title: "Construction Worker",
    company: "Delhi Metro Corp",
    location: "Delhi NCR",
    type: "Full-time",
    duration: "3 months",
    salary: "25,000/month",
    points: 500,
    premium: true,
  },
  {
    id: 2,
    title: "Delivery Associate",
    company: "QuickMart",
    location: "Gurgaon",
    type: "Flexible",
    duration: "Ongoing",
    salary: "20,000/month",
    points: 300,
    premium: false,
  },
  {
    id: 3,
    title: "Warehouse Assistant",
    company: "Global Logistics",
    location: "Noida",
    type: "Full-time",
    duration: "6 months",
    salary: "22,000/month",
    points: 450,
    premium: false,
  },
  {
    id: 4,
    title: "Security Guard",
    company: "SecureForce",
    location: "Delhi",
    type: "Full-time",
    duration: "12 months",
    salary: "18,000/month",
    points: 400,
    premium: true,
  },
  {
    id: 5,
    title: "Retail Associate",
    company: "MegaMart",
    location: "Delhi",
    type: "Part-time",
    duration: "Weekends",
    salary: "12,000/month",
    points: 250,
    premium: false,
  },
  {
    id: 6,
    title: "Factory Worker",
    company: "AutoParts Ltd",
    location: "Faridabad",
    type: "Full-time",
    duration: "Permanent",
    salary: "22,000/month",
    points: 500,
    premium: false,
  },
]

