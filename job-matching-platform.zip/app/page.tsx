import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"
import { Badge } from "@/components/ui/badge"
import { Progress } from "@/components/ui/progress"
import { Button } from "@/components/ui/button"
import { Briefcase, Star, Wallet, TrendingUp, Award, Clock } from "lucide-react"
import Link from "next/link"

export default function Dashboard() {
  return (
    <div className="flex flex-col p-6 space-y-6">
      <div className="flex flex-col space-y-2">
        <h1 className="text-3xl font-bold tracking-tight">Welcome back, Rahul</h1>
        <p className="text-muted-foreground">Here's an overview of your job matches and loyalty status</p>
      </div>

      <div className="grid gap-6 md:grid-cols-2 lg:grid-cols-3">
        <Card>
          <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
            <CardTitle className="text-sm font-medium">Trust Score</CardTitle>
            <Star className="h-4 w-4 text-yellow-500" />
          </CardHeader>
          <CardContent>
            <div className="text-2xl font-bold">4.8/5.0</div>
            <p className="text-xs text-muted-foreground">Based on 24 job completions</p>
            <Progress className="mt-3" value={96} />
          </CardContent>
        </Card>

        <Card>
          <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
            <CardTitle className="text-sm font-medium">Loyalty Points</CardTitle>
            <Wallet className="h-4 w-4 text-blue-500" />
          </CardHeader>
          <CardContent>
            <div className="text-2xl font-bold">3,250</div>
            <p className="text-xs text-muted-foreground">+450 points this month</p>
            <div className="mt-3">
              <Link href="/loyalty">
                <Button size="sm" variant="outline" className="w-full">
                  View Rewards
                </Button>
              </Link>
            </div>
          </CardContent>
        </Card>

        <Card>
          <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
            <CardTitle className="text-sm font-medium">Active Jobs</CardTitle>
            <Briefcase className="h-4 w-4 text-green-500" />
          </CardHeader>
          <CardContent>
            <div className="text-2xl font-bold">2</div>
            <p className="text-xs text-muted-foreground">Construction (1), Delivery (1)</p>
            <div className="mt-3">
              <Link href="/my-jobs">
                <Button size="sm" variant="outline" className="w-full">
                  View Jobs
                </Button>
              </Link>
            </div>
          </CardContent>
        </Card>
      </div>

      <h2 className="text-xl font-semibold mt-6">Recommended Jobs</h2>
      <div className="grid gap-6 md:grid-cols-2">
        {recommendedJobs.map((job) => (
          <Card key={job.id}>
            <CardHeader>
              <div className="flex items-center justify-between">
                <CardTitle>{job.title}</CardTitle>
                <Badge variant={job.premium ? "default" : "secondary"}>{job.premium ? "Premium" : "Regular"}</Badge>
              </div>
              <CardDescription>
                {job.company} • {job.location}
              </CardDescription>
            </CardHeader>
            <CardContent>
              <div className="flex items-center space-x-4 text-sm mb-4">
                <div className="flex items-center">
                  <Clock className="mr-1 h-4 w-4 text-muted-foreground" />
                  <span>{job.duration}</span>
                </div>
                <div className="flex items-center">
                  <Wallet className="mr-1 h-4 w-4 text-muted-foreground" />
                  <span>₹{job.salary}</span>
                </div>
                <div className="flex items-center">
                  <Award className="mr-1 h-4 w-4 text-muted-foreground" />
                  <span>+{job.points} points</span>
                </div>
              </div>
              <div className="flex space-x-2">
                <Button size="sm">Apply Now</Button>
                <Button size="sm" variant="outline">
                  Details
                </Button>
              </div>
            </CardContent>
          </Card>
        ))}
      </div>

      <div className="grid gap-6 md:grid-cols-2">
        <Card>
          <CardHeader>
            <CardTitle>Loyalty Status</CardTitle>
            <CardDescription>Your current tier and benefits</CardDescription>
          </CardHeader>
          <CardContent>
            <div className="flex items-center space-x-2 mb-4">
              <Badge variant="success">Silver Tier</Badge>
              <span className="text-sm text-muted-foreground">750 points until Gold</span>
            </div>
            <div className="space-y-2">
              <div className="flex justify-between text-sm">
                <span>Progress to Gold</span>
                <span>3,250 / 4,000</span>
              </div>
              <Progress value={81} />
            </div>
            <div className="mt-4 space-y-2">
              <h4 className="font-medium">Available Benefits:</h4>
              <ul className="text-sm space-y-1">
                <li className="flex items-center">
                  <TrendingUp className="mr-2 h-4 w-4 text-green-500" />
                  10% discount on grocery purchases
                </li>
                <li className="flex items-center">
                  <TrendingUp className="mr-2 h-4 w-4 text-green-500" />
                  Health insurance benefits
                </li>
                <li className="flex items-center">
                  <TrendingUp className="mr-2 h-4 w-4 text-green-500" />
                  Priority job matching
                </li>
              </ul>
            </div>
          </CardContent>
        </Card>

        <Card>
          <CardHeader>
            <CardTitle>Recent Ratings</CardTitle>
            <CardDescription>Feedback from your recent jobs</CardDescription>
          </CardHeader>
          <CardContent>
            <div className="space-y-4">
              {recentRatings.map((rating) => (
                <div key={rating.id} className="border-b pb-3 last:border-0">
                  <div className="flex justify-between mb-1">
                    <span className="font-medium">{rating.jobTitle}</span>
                    <div className="flex">
                      {Array(5)
                        .fill(0)
                        .map((_, i) => (
                          <Star
                            key={i}
                            className={`h-4 w-4 ${i < rating.rating ? "text-yellow-500 fill-yellow-500" : "text-gray-300"}`}
                          />
                        ))}
                    </div>
                  </div>
                  <p className="text-sm text-muted-foreground">{rating.comment}</p>
                  <div className="text-xs text-muted-foreground mt-1">{rating.date}</div>
                </div>
              ))}
            </div>
          </CardContent>
        </Card>
      </div>
    </div>
  )
}

const recommendedJobs = [
  {
    id: 1,
    title: "Construction Worker",
    company: "Delhi Metro Corp",
    location: "Delhi NCR",
    duration: "3 months",
    salary: "25,000/month",
    points: 500,
    premium: true,
  },
  {
    id: 2,
    title: "Delivery Associate",
    company: "QuickMart",
    location: "Gurgaon",
    duration: "Flexible",
    salary: "20,000/month",
    points: 300,
    premium: false,
  },
  {
    id: 3,
    title: "Warehouse Assistant",
    company: "Global Logistics",
    location: "Noida",
    duration: "6 months",
    salary: "22,000/month",
    points: 450,
    premium: false,
  },
  {
    id: 4,
    title: "Security Guard",
    company: "SecureForce",
    location: "Delhi",
    duration: "12 months",
    salary: "18,000/month",
    points: 400,
    premium: true,
  },
]

const recentRatings = [
  {
    id: 1,
    jobTitle: "Construction Worker at BuildRight",
    rating: 5,
    comment: "Rahul was punctual and completed all tasks efficiently.",
    date: "2 days ago",
  },
  {
    id: 2,
    jobTitle: "Delivery Associate at FastDelivery",
    rating: 4,
    comment: "Good work ethic and customer service skills.",
    date: "1 week ago",
  },
  {
    id: 3,
    jobTitle: "Warehouse Helper at StoragePlus",
    rating: 5,
    comment: "Excellent attention to detail and organization skills.",
    date: "2 weeks ago",
  },
]

